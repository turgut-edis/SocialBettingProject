export default [
    {
      id: 10,
      firstName: "Earvin",
      lastName: "Johnson",
      college: "Michigan State",
      team: "LA Lakers",
      projects: [
        {
          id: "1",
          name: "test 1"
        }
      ],
      stats: {
        height: "6-9",
        weight: "215 lbs",
        position: "Shooting Guard"
      }
    },
    {
      id: 20,
      firstName: "Michael",
      lastName: "Jordan",
      college: "Michigan State",
      team: "Chicago Bulls",
      projects: [
        {
          id: "1",
          name: "test 1"
        },
        {
          id: "2",
          name: "test 2"
        },
        {
          id: "3",
          name: "test 3"
        }
      ],
      stats: {
        height: "6-6",
        weight: "195 lbs",
        position: "Small Forward"
      }
    },
    {
      id: 30,
      firstName: "Lebron",
      lastName: "James",
      college: "NA",
      team: "LA Lakers",
      projects: [
        {
          id: "1",
          name: "test 1"
        },
        {
          id: "2",
          name: "test 2"
        },
        {
          id: "3",
          name: "test 3"
        }
      ],
      stats: {
        height: "6-8",
        weight: "250 lbs",
        position: "Shooting Guard"
      }
    }
  ];
  